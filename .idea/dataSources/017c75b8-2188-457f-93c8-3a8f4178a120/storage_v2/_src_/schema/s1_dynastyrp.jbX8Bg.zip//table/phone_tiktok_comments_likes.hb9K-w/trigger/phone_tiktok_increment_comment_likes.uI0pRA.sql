create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_comment_likes
    after insert
    on phone_tiktok_comments_likes
    for each row
BEGIN
    UPDATE phone_tiktok_comments
    SET likes = likes + 1
    WHERE id = NEW.comment_id;
END;

