create definer = u1_eT4NfjWt6m@`%` trigger phone_twitter_update_like_count_after_like
    after insert
    on phone_twitter_likes
    for each row
BEGIN
    UPDATE phone_twitter_tweets
    SET like_count = like_count + 1
    WHERE id = NEW.tweet_id;
END;

