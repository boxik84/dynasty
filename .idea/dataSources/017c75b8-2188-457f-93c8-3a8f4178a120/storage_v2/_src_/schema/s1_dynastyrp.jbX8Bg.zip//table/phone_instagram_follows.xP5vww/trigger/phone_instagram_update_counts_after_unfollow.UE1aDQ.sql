create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_update_counts_after_unfollow
    after delete
    on phone_instagram_follows
    for each row
BEGIN
    UPDATE phone_instagram_accounts
    SET follower_count = follower_count - 1
    WHERE username = OLD.followed;

    UPDATE phone_instagram_accounts
    SET following_count = following_count - 1
    WHERE username = OLD.follower;
END;

