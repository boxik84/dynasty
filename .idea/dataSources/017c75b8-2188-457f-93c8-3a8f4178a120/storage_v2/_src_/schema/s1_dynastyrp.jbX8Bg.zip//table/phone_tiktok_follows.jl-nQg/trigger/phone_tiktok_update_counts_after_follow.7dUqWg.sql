create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_update_counts_after_follow
    after insert
    on phone_tiktok_follows
    for each row
BEGIN
    -- Increment the follower_count for the followed user
    UPDATE phone_tiktok_accounts
    SET follower_count = follower_count + 1
    WHERE username = NEW.followed;

    -- Increment the following_count for the follower user
    UPDATE phone_tiktok_accounts
    SET following_count = following_count + 1
    WHERE username = NEW.follower;
END;

