create definer = u1_eT4NfjWt6m@`%` trigger phone_twitter_update_retweet_count_after_retweet
    after insert
    on phone_twitter_retweets
    for each row
BEGIN
    UPDATE phone_twitter_tweets
    SET retweet_count = retweet_count + 1
    WHERE id = NEW.tweet_id;
END;

