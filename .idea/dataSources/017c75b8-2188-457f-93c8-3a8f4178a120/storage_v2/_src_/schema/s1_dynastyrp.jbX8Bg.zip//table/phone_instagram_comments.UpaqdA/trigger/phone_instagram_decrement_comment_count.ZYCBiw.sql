create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_decrement_comment_count
    after delete
    on phone_instagram_comments
    for each row
BEGIN
    UPDATE phone_instagram_posts
    SET comment_count = comment_count - 1
    WHERE id = OLD.post_id;
END;

