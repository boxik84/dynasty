create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_video_count
    after insert
    on phone_tiktok_videos
    for each row
BEGIN
    UPDATE phone_tiktok_accounts
    SET video_count = video_count + 1
    WHERE username = NEW.username;
END;

