create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_increment_comment_count
    after insert
    on phone_instagram_comments
    for each row
BEGIN
    UPDATE phone_instagram_posts
    SET comment_count = comment_count + 1
    WHERE id = NEW.post_id;
END;

