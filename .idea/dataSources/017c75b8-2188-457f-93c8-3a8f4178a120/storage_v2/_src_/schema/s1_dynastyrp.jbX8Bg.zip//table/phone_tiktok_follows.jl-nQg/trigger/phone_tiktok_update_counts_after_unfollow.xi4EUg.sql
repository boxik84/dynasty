create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_update_counts_after_unfollow
    after delete
    on phone_tiktok_follows
    for each row
BEGIN
    -- Decrement the follower_count for the followed user
    UPDATE phone_tiktok_accounts
    SET follower_count = follower_count - 1
    WHERE username = OLD.followed;

    -- Decrement the following_count for the follower user
    UPDATE phone_tiktok_accounts
    SET following_count = following_count - 1
    WHERE username = OLD.follower;
END;

