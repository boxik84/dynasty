create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_video_saves
    after insert
    on phone_tiktok_saves
    for each row
BEGIN
    UPDATE phone_tiktok_videos
    SET saves = saves + 1
    WHERE id = NEW.video_id;
END;

