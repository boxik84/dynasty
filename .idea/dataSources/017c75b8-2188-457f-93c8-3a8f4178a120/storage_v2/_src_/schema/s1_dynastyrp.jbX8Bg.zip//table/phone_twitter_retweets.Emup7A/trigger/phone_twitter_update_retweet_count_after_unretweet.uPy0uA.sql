create definer = u1_eT4NfjWt6m@`%` trigger phone_twitter_update_retweet_count_after_unretweet
    after delete
    on phone_twitter_retweets
    for each row
BEGIN
    UPDATE phone_twitter_tweets
    SET retweet_count = retweet_count - 1
    WHERE id = OLD.tweet_id;
END;

