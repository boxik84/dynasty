create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_account_likes
    after insert
    on phone_tiktok_likes
    for each row
BEGIN
    UPDATE phone_tiktok_accounts
    JOIN phone_tiktok_videos ON phone_tiktok_videos.username = phone_tiktok_accounts.username
    SET phone_tiktok_accounts.like_count = phone_tiktok_accounts.like_count + 1
    WHERE phone_tiktok_videos.id = NEW.video_id;
END;

