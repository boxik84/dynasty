create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_decrement_like_count
    after delete
    on phone_instagram_likes
    for each row
BEGIN
    IF OLD.is_comment = 0 THEN
        UPDATE phone_instagram_posts
        SET like_count = like_count - 1
        WHERE id = OLD.id;
    ELSE
        UPDATE phone_instagram_comments
        SET like_count = like_count - 1
        WHERE id = OLD.id;
    END IF;
END;

