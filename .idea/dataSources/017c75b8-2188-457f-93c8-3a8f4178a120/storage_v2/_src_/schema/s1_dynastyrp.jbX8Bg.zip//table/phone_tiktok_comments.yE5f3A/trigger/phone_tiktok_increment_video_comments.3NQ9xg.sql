create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_video_comments
    after insert
    on phone_tiktok_comments
    for each row
BEGIN
    UPDATE phone_tiktok_videos
    SET comments = comments + 1
    WHERE id = NEW.video_id;
END;

