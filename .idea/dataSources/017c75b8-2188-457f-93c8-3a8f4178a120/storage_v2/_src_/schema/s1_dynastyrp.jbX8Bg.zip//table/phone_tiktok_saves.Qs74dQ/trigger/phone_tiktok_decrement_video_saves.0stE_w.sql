create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_decrement_video_saves
    after delete
    on phone_tiktok_saves
    for each row
BEGIN
    UPDATE phone_tiktok_videos
    SET saves = saves - 1
    WHERE id = OLD.video_id;
END;

