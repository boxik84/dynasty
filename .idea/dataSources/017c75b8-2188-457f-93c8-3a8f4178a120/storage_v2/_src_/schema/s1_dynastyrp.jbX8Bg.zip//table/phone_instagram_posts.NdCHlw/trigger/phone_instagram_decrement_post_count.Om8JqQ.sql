create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_decrement_post_count
    after delete
    on phone_instagram_posts
    for each row
BEGIN
    UPDATE phone_instagram_accounts
    SET post_count = post_count - 1
    WHERE username = OLD.username;
END;

