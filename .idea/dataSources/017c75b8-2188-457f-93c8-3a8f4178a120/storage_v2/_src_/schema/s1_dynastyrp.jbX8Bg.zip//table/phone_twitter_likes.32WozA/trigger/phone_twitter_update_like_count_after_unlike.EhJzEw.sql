create definer = u1_eT4NfjWt6m@`%` trigger phone_twitter_update_like_count_after_unlike
    after delete
    on phone_twitter_likes
    for each row
BEGIN
    UPDATE phone_twitter_tweets
    SET like_count = like_count - 1
    WHERE id = OLD.tweet_id;
END;

