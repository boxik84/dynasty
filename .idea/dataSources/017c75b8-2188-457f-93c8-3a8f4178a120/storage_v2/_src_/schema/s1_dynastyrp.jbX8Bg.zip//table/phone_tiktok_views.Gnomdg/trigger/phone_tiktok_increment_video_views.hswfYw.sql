create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_increment_video_views
    after insert
    on phone_tiktok_views
    for each row
BEGIN
    UPDATE phone_tiktok_videos
    SET views = views + 1
    WHERE id = NEW.video_id;
END;

