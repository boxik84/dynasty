create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_increment_story_count
    after insert
    on phone_instagram_stories
    for each row
BEGIN
    UPDATE phone_instagram_accounts
    SET story_count = story_count + 1
    WHERE username = NEW.username;
END;

