create definer = u1_eT4NfjWt6m@`%` trigger phone_instagram_decrement_story_count
    after delete
    on phone_instagram_stories
    for each row
BEGIN
    UPDATE phone_instagram_accounts
    SET story_count = story_count - 1
    WHERE username = OLD.username;
END;

