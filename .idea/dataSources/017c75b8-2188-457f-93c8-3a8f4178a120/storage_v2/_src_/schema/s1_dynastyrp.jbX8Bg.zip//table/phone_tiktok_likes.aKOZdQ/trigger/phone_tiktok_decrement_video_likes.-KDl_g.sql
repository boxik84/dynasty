create definer = u1_eT4NfjWt6m@`%` trigger phone_tiktok_decrement_video_likes
    after delete
    on phone_tiktok_likes
    for each row
BEGIN
    UPDATE phone_tiktok_videos
    SET likes = likes - 1
    WHERE id = OLD.video_id;
END;

